# 🔄 Configuração de Sincronização Automática com Google Drive

## ✅ Como Funciona

Quando configurado, o app irá:
- **Salvar automaticamente** todos os dados no Google Drive ao criar, editar ou excluir itens
- **Restaurar automaticamente** os dados do Google Drive ao abrir o app (se não houver dados locais)
- **Backup a cada 5 minutos** como segurança adicional

---

## 📋 Passo a Passo para Configurar

### ✨ SIMPLIFICADO - Client ID Já Configurado!

O Google Client ID já vem pré-configurado no app:
```
305705048348-jbfvtamh0llghkfiuntt9bqlc48vhukc.apps.googleusercontent.com
```

**Você só precisa fazer 2 passos:**

### 1️⃣ Configurar no App

1. Abra o app e faça login
2. Vá em **Configurações** (ícone de engrenagem)
3. Role até **"Configurações Avançadas de Backup"** e expanda
4. Na seção **"Google Drive - Sincronização Automática"**:
   - O **Google Client ID** já está preenchido
   - Clique em **Conectar com Google Drive**
   - Autorize o app no popup do Google

### 2️⃣ Ativar Sincronização Automática

1. Ainda em **Configurações Avançadas de Backup**
2. Na seção **"Modo de Sincronização"**
3. Selecione: **Local + Google Drive**

**Pronto! ✅** A sincronização automática está ativa!

---

## 🔧 Avançado: Usar Seu Próprio Client ID (Opcional)

Se quiser usar suas próprias credenciais:

### 1. Criar Credenciais do Google Cloud

1. Acesse: [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Crie um novo projeto ou selecione um existente
3. Vá em **APIs e Serviços** > **Credenciais**
4. Clique em **Criar credenciais** > **ID do cliente OAuth 2.0**
5. Selecione tipo: **Aplicativo da Web**

### 2. Configurar URIs de Redirecionamento

Na configuração do OAuth 2.0:

1. Em **URIs de redirecionamento autorizados**, adicione:
   ```
   https://seu-dominio.com/oauth-callback.html
   ```
   
   Por exemplo:
   - `https://stack-chrome-89765457.figma.site/oauth-callback.html`
   - `http://localhost:5173/oauth-callback.html` (para desenvolvimento)

2. Salve e copie o **Client ID** gerado
3. Cole no campo **Google Client ID** no app e salve

---

## 🎯 Verificar se está Funcionando

No topo das **Configurações Avançadas de Backup**, você verá:

✅ **Sincronização Ativa:** Dados sendo salvos no Google Drive
- Backup automático ao salvar itens
- Restauração automática ao abrir o app

---

## 🔧 Arquivos Modificados (para commit no GitHub)

### Novos:
1. `src/app/components/RestoreBanner.tsx`
2. `public/oauth-callback.html` (atualizado)
3. `GOOGLE_DRIVE_SETUP.md` (este arquivo)

### Modificados:
4. `src/app/utils/syncService.ts` - Sincronização automática
5. `src/app/utils/api.ts` - Endpoint de estatísticas
6. `src/app/utils/googleDriveBackup.ts` - Melhorias
7. `src/app/components/BackupSettings.tsx` - UI de configuração
8. `src/app/pages/Login.tsx` - Botão de restauração
9. `src/app/pages/Home.tsx` - Banner de restauração
10. `src/app/pages/Settings.tsx` - Correção de LogOut
11. `src/app/App.tsx` - Auto-restauração
12. `supabase/functions/server/index.tsx` - Endpoint de stats

**Total: 12 arquivos**

---

## ⚠️ Importante

- O **Google Drive é opcional** - você pode usar apenas o modo local
- Para recuperar dados do Supabase, use o botão **"Restaurar do Supabase"** (não requer Google Drive)
- Os dados do Google Drive ficam na sua conta pessoal do Google

---

## 🆘 Solução de Problemas

### Erro: "Failed to open popup"
- Habilite popups para este site no navegador

### Não está salvando automaticamente
- Verifique se o modo está em **"Local + Google Drive"**
- Confirme que você está autenticado (ícone verde de conectado)

### Dados não aparecem ao abrir
- A restauração automática só acontece se não houver dados locais
- Use o botão **"Restaurar"** manual se necessário
