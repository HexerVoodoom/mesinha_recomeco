// Sync service to manage local storage, Supabase, and Google Drive
import { localDB } from './localDB';
import { googleDriveBackup } from './googleDriveBackup';
import { toast } from 'sonner';
import { projectId, publicAnonKey } from '/utils/supabase/info';

export type SyncMode = 'local-only' | 'local-with-drive' | 'local-drive-supabase';

class SyncService {
  private syncMode: SyncMode = 'local-only';
  private autoBackupInterval: number | null = null;
  private lastBackupTime: number = 0;
  private lastSyncTime: number = 0;
  private isSyncing: boolean = false;

  constructor() {
    // Load sync mode from localStorage
    const storedMode = localStorage.getItem('sync_mode') as SyncMode;
    if (storedMode) {
      this.syncMode = storedMode;
    } else {
      // Default to local-only if not set
      localStorage.setItem('sync_mode', 'local-only');
    }

    // Load last backup time
    const lastBackup = localStorage.getItem('last_backup_time');
    if (lastBackup) {
      this.lastBackupTime = parseInt(lastBackup, 10);
    }

    // Load last sync time
    const lastSync = localStorage.getItem('last_sync_time');
    if (lastSync) {
      this.lastSyncTime = parseInt(lastSync, 10);
    }
  }

  getSyncMode(): SyncMode {
    return this.syncMode;
  }

  setSyncMode(mode: SyncMode): void {
    this.syncMode = mode;
    localStorage.setItem('sync_mode', mode);

    // Restart auto-backup with new mode
    if (this.autoBackupInterval) {
      this.stopAutoBackup();
      this.startAutoBackup();
    }
  }

  async saveItem(item: any): Promise<void> {
    try {
      // Add/update timestamp
      item.updatedAt = new Date().toISOString();
      if (!item.createdAt) {
        item.createdAt = new Date().toISOString();
      }

      // Always save locally first
      await localDB.saveItem(item);
      console.log('[SyncService] Item saved locally:', item.id);

      // Trigger immediate backup for Google Drive mode
      if (this.syncMode === 'local-with-drive') {
        // Backup immediately on save (debounced)
        this.debouncedBackup();
      }
    } catch (error) {
      console.error('[SyncService] Error saving item:', error);
      throw error;
    }
  }

  private backupTimeout: number | null = null;

  private debouncedBackup(): void {
    // Clear existing timeout
    if (this.backupTimeout) {
      clearTimeout(this.backupTimeout);
    }

    // Wait 2 seconds before backing up (to batch multiple changes)
    this.backupTimeout = window.setTimeout(() => {
      this.performBackup().catch(err =>
        console.log('[SyncService] Background backup skipped:', err.message)
      );
    }, 2000);
  }

  async deleteItem(id: string): Promise<void> {
    try {
      await localDB.deleteItem(id);
      console.log('[SyncService] Item deleted locally:', id);

      // Trigger immediate backup for Google Drive mode
      if (this.syncMode === 'local-with-drive') {
        this.debouncedBackup();
      }
    } catch (error) {
      console.error('[SyncService] Error deleting item:', error);
      throw error;
    }
  }

  async getItems(category?: string): Promise<any[]> {
    try {
      if (category) {
        return await localDB.getItemsByCategory(category);
      }
      return await localDB.getAllItems();
    } catch (error) {
      console.error('[SyncService] Error getting items:', error);
      return [];
    }
  }

  async getItem(id: string): Promise<any | null> {
    try {
      return await localDB.getItem(id);
    } catch (error) {
      console.error('[SyncService] Error getting item:', error);
      return null;
    }
  }

  async saveSettings(settings: any): Promise<void> {
    try {
      await localDB.saveSettings(settings);
      console.log('[SyncService] Settings saved locally');

      // Trigger immediate backup for Google Drive mode
      if (this.syncMode === 'local-with-drive') {
        this.debouncedBackup();
      }
    } catch (error) {
      console.error('[SyncService] Error saving settings:', error);
      throw error;
    }
  }

  async getSettings(): Promise<any> {
    try {
      const settings = await localDB.getSettings();
      return settings || {
        coupleName: "You & Partner",
        themeColor: "#81D8D0",
        notificationsEnabled: true,
      };
    } catch (error) {
      console.error('[SyncService] Error getting settings:', error);
      return {
        coupleName: "You & Partner",
        themeColor: "#81D8D0",
        notificationsEnabled: true,
      };
    }
  }

  private async triggerBackupIfNeeded(): Promise<void> {
    const now = Date.now();
    const timeSinceLastBackup = now - this.lastBackupTime;

    // Backup every 5 minutes at most
    if (timeSinceLastBackup < 5 * 60 * 1000) {
      console.log('[SyncService] Skipping backup, too soon since last backup');
      return;
    }

    await this.performBackup();
  }

  async performBackup(showToast: boolean = false): Promise<void> {
    try {
      if (showToast) {
        toast.loading('Criando backup...', { id: 'backup' });
      }

      const backupData = await localDB.exportData();

      // Backup to Google Drive only if authenticated and configured
      if (this.syncMode === 'local-with-drive' || this.syncMode === 'local-drive-supabase') {
        const hasClientId = !!localStorage.getItem('google_client_id');
        const isAuth = googleDriveBackup.isAuthenticated();

        if (!hasClientId) {
          if (showToast) {
            toast.warning('Configure o Google Client ID nas configurações', { id: 'backup' });
          }
        } else if (!isAuth) {
          if (showToast) {
            toast.warning('Conecte-se ao Google Drive para fazer backup na nuvem', { id: 'backup' });
          }
        } else {
          // Both client ID and authentication present
          try {
            await googleDriveBackup.uploadBackup(backupData);
            console.log('[SyncService] Backup uploaded to Google Drive');
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            console.log('[SyncService] Google Drive backup skipped:', errorMsg);
            if (showToast) {
              toast.error('Erro ao fazer backup no Google Drive', { id: 'backup' });
              throw error;
            }
          }
        }
      }

      this.lastBackupTime = Date.now();
      localStorage.setItem('last_backup_time', this.lastBackupTime.toString());

      if (showToast) {
        toast.success('Backup local realizado com sucesso!', { id: 'backup' });
      }
    } catch (error) {
      console.error('[SyncService] Backup failed:', error);
      if (showToast) {
        toast.error('Erro ao criar backup', { id: 'backup' });
      }
      throw error;
    }
  }

  async restoreFromGoogleDrive(): Promise<void> {
    try {
      toast.loading('Restaurando backup do Google Drive...', { id: 'restore' });

      const backupData = await googleDriveBackup.downloadBackup();

      if (!backupData) {
        toast.error('Nenhum backup encontrado no Google Drive', { id: 'restore' });
        return;
      }

      await localDB.importData(backupData);

      toast.success('Backup restaurado com sucesso!', { id: 'restore' });

      // Reload the page to reflect changes
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error('[SyncService] Restore failed:', error);
      toast.error('Erro ao restaurar backup', { id: 'restore' });
      throw error;
    }
  }

  async restoreFromSupabase(): Promise<void> {
    try {
      toast.loading('Restaurando backup do Supabase...', { id: 'restore' });

      const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-19717bce`;

      // Fetch backup directly from Supabase
      const response = await fetch(`${BASE_URL}/backup`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch backup from Supabase');
      }

      const backupData = await response.json();

      if (!backupData || !backupData.data) {
        toast.error('Nenhum backup encontrado no Supabase', { id: 'restore' });
        return;
      }

      await localDB.importData(backupData);

      toast.success('Backup do Supabase restaurado com sucesso!', { id: 'restore' });

      // Reload the page to reflect changes
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error('[SyncService] Supabase restore failed:', error);
      toast.error('Erro ao restaurar backup do Supabase', { id: 'restore' });
      throw error;
    }
  }

  startAutoBackup(intervalMinutes: number = 30): void {
    this.stopAutoBackup();

    if (this.syncMode === 'local-only') {
      console.log('[SyncService] Auto-sync disabled for local-only mode');
      return;
    }

    console.log(`[SyncService] Starting auto-sync every ${intervalMinutes} minutes`);

    this.autoBackupInterval = window.setInterval(() => {
      console.log('[SyncService] Running scheduled sync...');

      if (this.syncMode === 'local-with-drive') {
        // Bidirectional sync with Google Drive
        this.syncWithGoogleDrive(false).catch(err => {
          console.log('[SyncService] Auto-sync skipped:', err.message);
        });
      } else {
        // Just backup
        this.performBackup().catch(err => {
          console.log('[SyncService] Auto-backup skipped:', err.message);
        });
      }
    }, intervalMinutes * 60 * 1000);

    // Do an initial sync/backup (silently handle errors)
    if (this.syncMode === 'local-with-drive') {
      this.syncWithGoogleDrive(false).catch(err => {
        console.log('[SyncService] Initial sync skipped:', err.message);
      });
    } else {
      this.performBackup().catch(err => {
        console.log('[SyncService] Initial backup skipped:', err.message);
      });
    }
  }

  stopAutoBackup(): void {
    if (this.autoBackupInterval) {
      clearInterval(this.autoBackupInterval);
      this.autoBackupInterval = null;
      console.log('[SyncService] Auto-backup stopped');
    }
  }

  getLastBackupTime(): number {
    return this.lastBackupTime;
  }

  getLastSyncTime(): number {
    return this.lastSyncTime;
  }

  async syncWithGoogleDrive(showToast: boolean = false): Promise<void> {
    if (this.isSyncing) {
      console.log('[SyncService] Sync already in progress, skipping');
      return;
    }

    if (this.syncMode !== 'local-with-drive') {
      console.log('[SyncService] Google Drive sync not enabled');
      return;
    }

    if (!googleDriveBackup.isAuthenticated()) {
      console.log('[SyncService] Not authenticated with Google Drive');
      return;
    }

    this.isSyncing = true;

    try {
      if (showToast) {
        toast.loading('Sincronizando com Google Drive...', { id: 'sync' });
      }

      console.log('[SyncService] Starting bidirectional sync...');

      // 1. Download current state from Google Drive
      const driveData = await googleDriveBackup.downloadBackup();

      if (!driveData) {
        console.log('[SyncService] No data in Google Drive, uploading local data');
        await this.performBackup(false);
        this.lastSyncTime = Date.now();
        localStorage.setItem('last_sync_time', this.lastSyncTime.toString());
        if (showToast) {
          toast.success('Dados enviados para Google Drive', { id: 'sync' });
        }
        return;
      }

      // 2. Get local data
      const localItems = await localDB.getAllItems();
      const localSettings = await localDB.getSettings();

      // 3. Merge data intelligently
      const driveItems = driveData.data?.items || [];
      const driveSettings = driveData.data?.settings || {};

      // Create maps for easy lookup
      const localItemsMap = new Map(localItems.map(item => [item.id, item]));
      const driveItemsMap = new Map(driveItems.map((item: any) => [item.id, item]));

      let itemsChanged = false;

      // Merge items (newest wins)
      for (const driveItem of driveItems) {
        const localItem = localItemsMap.get(driveItem.id);

        if (!localItem) {
          // New item from Drive
          await localDB.saveItem(driveItem);
          itemsChanged = true;
          console.log('[SyncService] Added new item from Drive:', driveItem.id);
        } else {
          // Item exists locally, check which is newer
          const localTime = new Date(localItem.updatedAt || localItem.createdAt).getTime();
          const driveTime = new Date(driveItem.updatedAt || driveItem.createdAt).getTime();

          if (driveTime > localTime) {
            // Drive version is newer
            await localDB.saveItem(driveItem);
            itemsChanged = true;
            console.log('[SyncService] Updated item from Drive (newer):', driveItem.id);
          }
        }
      }

      // Check for items that exist locally but not in Drive
      for (const localItem of localItems) {
        if (!driveItemsMap.has(localItem.id)) {
          // Local item not in Drive, we'll upload it on next backup
          itemsChanged = true;
          console.log('[SyncService] Local item not in Drive, will upload:', localItem.id);
        }
      }

      // If local items are newer or different, upload them
      if (itemsChanged || localItems.length !== driveItems.length) {
        console.log('[SyncService] Changes detected, uploading to Drive');
        await this.performBackup(false);
      }

      this.lastSyncTime = Date.now();
      localStorage.setItem('last_sync_time', this.lastSyncTime.toString());

      if (showToast) {
        toast.success('Sincronizado com Google Drive!', { id: 'sync' });
      }

      console.log('[SyncService] Sync completed successfully');
    } catch (error) {
      console.error('[SyncService] Sync failed:', error);
      if (showToast) {
        toast.error('Erro ao sincronizar', { id: 'sync' });
      }
    } finally {
      this.isSyncing = false;
    }
  }

  async exportLocalBackup(): Promise<Blob> {
    const backupData = await localDB.exportData();
    const json = JSON.stringify(backupData, null, 2);
    return new Blob([json], { type: 'application/json' });
  }

  async importLocalBackup(file: File): Promise<void> {
    try {
      const text = await file.text();
      const backupData = JSON.parse(text);

      await localDB.importData(backupData);

      toast.success('Backup importado com sucesso!');

      // Reload the page
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error('[SyncService] Import failed:', error);
      toast.error('Erro ao importar backup');
      throw error;
    }
  }
}

export const syncService = new SyncService();
